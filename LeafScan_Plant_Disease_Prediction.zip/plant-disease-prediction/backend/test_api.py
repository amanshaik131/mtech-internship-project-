"""
Command-line tester for the LeafScan API (test cases TC01-TC12 of the report).

Usage
-----
    python test_api.py                     # run all checks (server must be running)
    python test_api.py --image leaf.jpg    # also run a real prediction
    python test_api.py --url http://host:5000
"""
import argparse
import io
import json
import sys
import urllib.error
import urllib.request
import uuid

GREEN, RED, DIM, RESET = "\033[92m", "\033[91m", "\033[2m", "\033[0m"
results = []


def call(base, method, path, files=None):
    """Tiny HTTP helper using only the standard library."""
    data, headers = None, {}
    if files is not None:
        boundary = uuid.uuid4().hex
        body = io.BytesIO()
        for field, (filename, content, ctype) in files.items():
            body.write(f"--{boundary}\r\n".encode())
            body.write(f'Content-Disposition: form-data; name="{field}"; '
                       f'filename="{filename}"\r\n'.encode())
            body.write(f"Content-Type: {ctype}\r\n\r\n".encode())
            body.write(content)
            body.write(b"\r\n")
        body.write(f"--{boundary}--\r\n".encode())
        data = body.getvalue()
        headers["Content-Type"] = f"multipart/form-data; boundary={boundary}"
    req = urllib.request.Request(base + path, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return resp.status, json.loads(resp.read() or b"{}")
    except urllib.error.HTTPError as err:
        try:
            return err.code, json.loads(err.read() or b"{}")
        except json.JSONDecodeError:
            return err.code, {}


def check(test_id, name, condition, detail=""):
    results.append(condition)
    mark = f"{GREEN}PASS{RESET}" if condition else f"{RED}FAIL{RESET}"
    print(f"  {test_id:<5} {mark}  {name}  {DIM}{detail}{RESET}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://localhost:5000")
    ap.add_argument("--image", help="path to a real leaf image for TC02")
    args = ap.parse_args()
    base = args.url.rstrip("/")

    print(f"\nTesting LeafScan API at {base}\n")
    try:
        status, health = call(base, "GET", "/api/health")
    except urllib.error.URLError:
        print(f"{RED}Cannot reach the server. Start it with: python app.py{RESET}")
        sys.exit(1)

    model_loaded = health.get("model_loaded", False)
    check("TC01", "Server health", status == 200 and health.get("status") == "ok",
          f"model_loaded={model_loaded}")

    if args.image and model_loaded:
        with open(args.image, "rb") as fh:
            content = fh.read()
        status, res = call(base, "POST", "/api/predict",
                           {"image": (args.image, content, "image/jpeg")})
        ok = status == 200 and {"plant", "disease", "confidence", "top_predictions", "info"} <= res.keys()
        check("TC02", "Predict valid image", ok,
              f"{res.get('plant')} - {res.get('disease')} ({res.get('confidence', 0):.1%})" if ok else str(res))
    else:
        print(f"  TC02  {DIM}SKIP  Predict valid image (use --image and load the model){RESET}")

    status, res = call(base, "POST", "/api/predict", {})
    check("TC03", "Request without image -> 400", status == 400, res.get("error", ""))

    status, res = call(base, "POST", "/api/predict", {"image": ("", b"x", "image/jpeg")})
    check("TC04", "Empty file name -> 400", status == 400, res.get("error", ""))

    status, res = call(base, "POST", "/api/predict", {"image": ("config.py", b"x=1", "text/plain")})
    check("TC05", "Unsupported file type -> 400", status == 400, res.get("error", ""))

    big = b"0" * (11 * 1024 * 1024)
    try:
        status, res = call(base, "POST", "/api/predict", {"image": ("big.jpg", big, "image/jpeg")})
    except (ConnectionError, urllib.error.URLError):
        status, res = 413, {"error": "connection closed by server (limit enforced)"}
    check("TC06", "File larger than 10 MB -> 413", status == 413, res.get("error", ""))

    if model_loaded:
        status, res = call(base, "POST", "/api/predict",
                           {"image": ("fake.jpg", b"this is not an image", "image/jpeg")})
        check("TC07", "Corrupt image -> 422", status == 422, res.get("error", ""))
    else:
        status, res = call(base, "POST", "/api/predict",
                           {"image": ("leaf.jpg", b"data", "image/jpeg")})
        check("TC08", "Model missing -> 503", status == 503, res.get("error", "")[:60])

    status, res = call(base, "GET", "/api/history")
    check("TC09", "History endpoint", status == 200 and "history" in res,
          f"{len(res.get('history', []))} records")

    status, res = call(base, "GET", "/api/stats")
    check("TC10", "Statistics", status == 200 and {"total", "healthy", "diseased"} <= res.keys(),
          json.dumps(res))

    print(f"  TC11  {DIM}SKIP  Clear history (run DELETE /api/history manually to avoid data loss){RESET}")

    status, res = call(base, "GET", "/api/diseases")
    check("TC12", "Disease library has 38 classes", status == 200 and res.get("count") == 38,
          f"count={res.get('count')}")

    passed = sum(results)
    print(f"\n{passed}/{len(results)} checks passed\n")
    sys.exit(0 if passed == len(results) else 1)


if __name__ == "__main__":
    main()
