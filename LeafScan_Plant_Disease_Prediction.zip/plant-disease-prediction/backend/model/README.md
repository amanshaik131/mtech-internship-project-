# Model files

Place the trained model files here:

- `plant_disease_model.h5` — trained Keras model
- `class_names.json` — list of the 38 class names in output order

Both are created by `python train.py` (or the Colab notebook in `notebooks/`).
`training_history.png` and `metrics.json` are also written here for the report.
