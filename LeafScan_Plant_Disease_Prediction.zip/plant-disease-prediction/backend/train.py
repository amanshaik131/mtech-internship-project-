"""
Train the plant disease classifier with transfer learning (MobileNetV2).

Dataset: "New Plant Diseases Dataset (Augmented)" on Kaggle
https://www.kaggle.com/datasets/vipoooool/new-plant-diseases-dataset
It contains train/ and valid/ folders with one sub-folder per class (38).

Usage
-----
    python train.py --data "<path>/train" --val "<path>/valid"
    python train.py --data train --val valid --epochs 10 --fine-tune-epochs 5

Google Colab (free T4 GPU) is recommended: training takes ~30-45 minutes.

Two-stage training
------------------
Stage 1  frozen MobileNetV2 base, train new classifier head   (lr 1e-3)
Stage 2  unfreeze top 40 base layers and fine-tune together   (lr 1e-4)

Outputs (in backend/model/)
---------------------------
plant_disease_model.h5   best model
class_names.json         list of class names in output order
training_history.png     accuracy / loss curves
metrics.json             final validation metrics
"""
import argparse
import json
import os
import time

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf

from config import (
    BATCH_SIZE,
    CLASS_NAMES_PATH,
    HISTORY_PLOT_PATH,
    IMAGE_SIZE,
    MODEL_DIR,
    MODEL_PATH,
)

SEED = 42
FINE_TUNE_LAYERS = 40


def parse_args():
    p = argparse.ArgumentParser(description="Train LeafScan plant disease model")
    p.add_argument("--data", required=True, help="training folder (one sub-folder per class)")
    p.add_argument("--val", help="validation folder; if omitted 20%% of --data is used")
    p.add_argument("--epochs", type=int, default=10, help="stage 1 epochs (default 10)")
    p.add_argument("--fine-tune-epochs", type=int, default=5, help="stage 2 epochs (default 5)")
    p.add_argument("--batch-size", type=int, default=BATCH_SIZE)
    return p.parse_args()


def load_datasets(args):
    common = dict(
        image_size=IMAGE_SIZE,
        batch_size=args.batch_size,
        label_mode="categorical",
        seed=SEED,
    )
    if args.val:
        train_ds = tf.keras.utils.image_dataset_from_directory(args.data, shuffle=True, **common)
        val_ds = tf.keras.utils.image_dataset_from_directory(args.val, shuffle=False, **common)
    else:
        train_ds = tf.keras.utils.image_dataset_from_directory(
            args.data, validation_split=0.2, subset="training", shuffle=True, **common)
        val_ds = tf.keras.utils.image_dataset_from_directory(
            args.data, validation_split=0.2, subset="validation", shuffle=False, **common)

    class_names = train_ds.class_names
    autotune = tf.data.AUTOTUNE
    train_ds = train_ds.prefetch(autotune)
    val_ds = val_ds.cache().prefetch(autotune)
    return train_ds, val_ds, class_names


def build_model(num_classes):
    augmentation = tf.keras.Sequential(
        [
            tf.keras.layers.RandomFlip("horizontal_and_vertical"),
            tf.keras.layers.RandomRotation(0.15),
            tf.keras.layers.RandomZoom(0.15),
            tf.keras.layers.RandomContrast(0.1),
        ],
        name="augmentation",
    )

    base = tf.keras.applications.MobileNetV2(
        input_shape=IMAGE_SIZE + (3,), include_top=False, weights="imagenet"
    )
    base.trainable = False  # Stage 1: frozen base

    inputs = tf.keras.Input(shape=IMAGE_SIZE + (3,))
    x = augmentation(inputs)                                   # active only in training
    x = tf.keras.layers.Rescaling(1.0 / 127.5, offset=-1.0)(x)  # 0..255 -> -1..1
    x = base(x, training=False)
    x = tf.keras.layers.GlobalAveragePooling2D()(x)
    x = tf.keras.layers.Dropout(0.3)(x)
    x = tf.keras.layers.Dense(256, activation="relu")(x)
    x = tf.keras.layers.Dropout(0.2)(x)
    outputs = tf.keras.layers.Dense(num_classes, activation="softmax")(x)
    return tf.keras.Model(inputs, outputs, name="leafscan_mobilenetv2"), base


def callbacks():
    return [
        tf.keras.callbacks.ModelCheckpoint(
            MODEL_PATH, monitor="val_accuracy", save_best_only=True, verbose=1),
        tf.keras.callbacks.EarlyStopping(
            monitor="val_accuracy", patience=3, restore_best_weights=True, verbose=1),
        tf.keras.callbacks.ReduceLROnPlateau(
            monitor="val_loss", factor=0.2, patience=2, min_lr=1e-7, verbose=1),
    ]


def merge(h1, h2):
    return {k: h1.history.get(k, []) + (h2.history.get(k, []) if h2 else [])
            for k in h1.history}


def plot_history(hist, stage1_epochs):
    epochs = range(1, len(hist["accuracy"]) + 1)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.5))
    for ax, metric, title in ((ax1, "accuracy", "Accuracy"), (ax2, "loss", "Loss")):
        ax.plot(epochs, hist[metric], "o-", label=f"Training {metric}", color="#2e7d4f")
        ax.plot(epochs, hist[f"val_{metric}"], "s--", label=f"Validation {metric}", color="#d97706")
        ax.axvline(stage1_epochs + 0.5, color="#94a3b8", linestyle=":", label="Start fine-tuning")
        ax.set_title(f"Training and Validation {title}")
        ax.set_xlabel("Epoch")
        ax.set_ylabel(title)
        ax.grid(alpha=0.3)
        ax.legend()
    plt.tight_layout()
    plt.savefig(HISTORY_PLOT_PATH, dpi=150)
    print(f"[INFO] Training graph saved to {HISTORY_PLOT_PATH}")


def main():
    args = parse_args()
    tf.keras.utils.set_random_seed(SEED)
    os.makedirs(MODEL_DIR, exist_ok=True)

    train_ds, val_ds, class_names = load_datasets(args)
    num_classes = len(class_names)
    print(f"[INFO] Found {num_classes} classes")
    with open(CLASS_NAMES_PATH, "w", encoding="utf-8") as fh:
        json.dump(class_names, fh, indent=2)

    model, base = build_model(num_classes)
    model.summary()

    # ---------------- Stage 1: feature extraction
    print("\n[STAGE 1] Training classifier head (base frozen)")
    model.compile(optimizer=tf.keras.optimizers.Adam(1e-3),
                  loss="categorical_crossentropy", metrics=["accuracy"])
    h1 = model.fit(train_ds, validation_data=val_ds, epochs=args.epochs, callbacks=callbacks())
    stage1_epochs = len(h1.history["accuracy"])

    # ---------------- Stage 2: fine-tuning
    h2 = None
    if args.fine_tune_epochs > 0:
        print(f"\n[STAGE 2] Fine-tuning top {FINE_TUNE_LAYERS} layers of MobileNetV2")
        base.trainable = True
        for layer in base.layers[:-FINE_TUNE_LAYERS]:
            layer.trainable = False
        model.compile(optimizer=tf.keras.optimizers.Adam(1e-4),
                      loss="categorical_crossentropy", metrics=["accuracy"])
        h2 = model.fit(train_ds, validation_data=val_ds,
                       epochs=stage1_epochs + args.fine_tune_epochs,
                       initial_epoch=stage1_epochs, callbacks=callbacks())

    hist = merge(h1, h2)
    plot_history(hist, stage1_epochs)

    # ---------------- Evaluation
    best = tf.keras.models.load_model(MODEL_PATH, compile=False)
    best.compile(loss="categorical_crossentropy", metrics=["accuracy"])
    val_loss, val_acc = best.evaluate(val_ds, verbose=0)

    sample = np.zeros((1,) + IMAGE_SIZE + (3,), np.float32)
    best.predict(sample, verbose=0)
    start = time.perf_counter()
    for _ in range(20):
        best.predict(sample, verbose=0)
    avg_ms = (time.perf_counter() - start) / 20 * 1000

    metrics = {
        "training_accuracy": round(float(max(hist["accuracy"])), 4),
        "validation_accuracy": round(float(val_acc), 4),
        "validation_loss": round(float(val_loss), 4),
        "num_classes": num_classes,
        "model_size_mb": round(os.path.getsize(MODEL_PATH) / (1024 * 1024), 2),
        "avg_prediction_ms": round(avg_ms, 1),
        "epochs_trained": len(hist["accuracy"]),
    }
    with open(os.path.join(MODEL_DIR, "metrics.json"), "w") as fh:
        json.dump(metrics, fh, indent=2)

    print("\n" + "=" * 50)
    print(f"[RESULT] Training accuracy   : {metrics['training_accuracy'] * 100:.2f}%")
    print(f"[RESULT] Validation accuracy : {metrics['validation_accuracy'] * 100:.2f}%")
    print(f"[RESULT] Validation loss     : {metrics['validation_loss']:.4f}")
    print(f"[RESULT] Model size          : {metrics['model_size_mb']} MB")
    print(f"[RESULT] Avg prediction time : {metrics['avg_prediction_ms']} ms")
    print("=" * 50)
    print(f"[INFO] Model saved to {MODEL_PATH}")


if __name__ == "__main__":
    main()
