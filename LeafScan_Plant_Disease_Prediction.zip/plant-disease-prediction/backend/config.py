"""
Central configuration for LeafScan - Plant Disease Prediction using AI.

Every tunable setting lives here so that training, inference and the API
always agree on image size, file locations and the confidence threshold.
"""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ---------------------------------------------------------------- paths
MODEL_DIR = os.path.join(BASE_DIR, "model")
MODEL_PATH = os.environ.get(
    "MODEL_PATH", os.path.join(MODEL_DIR, "plant_disease_model.h5")
)
CLASS_NAMES_PATH = os.path.join(MODEL_DIR, "class_names.json")
HISTORY_PLOT_PATH = os.path.join(MODEL_DIR, "training_history.png")

UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
DATABASE_PATH = os.path.join(BASE_DIR, "predictions.db")

# ---------------------------------------------------------------- model
IMAGE_SIZE = (224, 224)          # must match training
BATCH_SIZE = 32
CONFIDENCE_THRESHOLD = 0.60      # below this, flag as "uncertain"
TOP_K = 3                        # number of alternative predictions returned

# ---------------------------------------------------------------- uploads
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}
MAX_CONTENT_LENGTH = 10 * 1024 * 1024   # 10 MB upload limit

# ---------------------------------------------------------------- server
HOST = os.environ.get("HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", 5000))
DEBUG = os.environ.get("FLASK_DEBUG", "0") == "1"
# Comma-separated list of allowed frontend origins ("*" = allow all)
CORS_ORIGINS = os.environ.get("CORS_ORIGINS", "*")

os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs(UPLOAD_DIR, exist_ok=True)
