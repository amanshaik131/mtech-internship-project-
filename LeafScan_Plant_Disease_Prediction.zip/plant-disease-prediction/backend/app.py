"""
LeafScan REST API - Plant Disease Prediction using AI.

Endpoints
---------
GET    /api/health            server status and whether the model is loaded
POST   /api/predict           upload an image (form field "image") -> prediction
GET    /api/diseases          all supported classes with disease information
GET    /api/history?limit=50  recent predictions
DELETE /api/history           clear the prediction history
GET    /api/stats             total / healthy / diseased counts
GET    /api/uploads/<file>    uploaded leaf image (used for history thumbnails)

Run:  python app.py   ->  http://localhost:5000
"""
import os
import uuid

from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
from werkzeug.exceptions import RequestEntityTooLarge
from werkzeug.utils import secure_filename

import config
from disease_info import list_diseases
from utils.database import (
    clear_history,
    get_filenames,
    get_history,
    get_stats,
    init_db,
    save_prediction,
)
from utils.predictor import Predictor

FRONTEND_DIST = os.path.join(config.BASE_DIR, "..", "frontend", "dist")

app = Flask(__name__, static_folder=None)
app.config["MAX_CONTENT_LENGTH"] = config.MAX_CONTENT_LENGTH
CORS(app, resources={r"/api/*": {"origins": config.CORS_ORIGINS.split(",")}})

init_db()
predictor = Predictor()


def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in config.ALLOWED_EXTENSIONS


# ------------------------------------------------------------------ errors
@app.errorhandler(RequestEntityTooLarge)
def too_large(_):
    limit_mb = config.MAX_CONTENT_LENGTH // (1024 * 1024)
    return jsonify({"error": f"File too large. Maximum size is {limit_mb} MB."}), 413


@app.errorhandler(404)
def not_found(_):
    if request.path.startswith("/api/"):
        return jsonify({"error": "Endpoint not found."}), 404
    return _serve_frontend("index.html")


@app.errorhandler(500)
def server_error(_):
    return jsonify({"error": "Internal server error. Please try again."}), 500


# ------------------------------------------------------------------ routes
@app.get("/api/health")
def health():
    return jsonify(
        {
            "status": "ok",
            "model_loaded": predictor.ready,
            "num_classes": len(predictor.class_names),
            "message": "Model ready" if predictor.ready else predictor.error,
        }
    )


@app.post("/api/predict")
def predict():
    if "image" not in request.files:
        return jsonify({"error": "No image uploaded. Send the file in the 'image' field."}), 400

    file = request.files["image"]
    if not file.filename:
        return jsonify({"error": "No file selected."}), 400
    if not allowed_file(file.filename):
        allowed = ", ".join(sorted(config.ALLOWED_EXTENSIONS)).upper()
        return jsonify({"error": f"Unsupported file type. Please upload {allowed}."}), 400

    if not predictor.ready:
        return jsonify({"error": predictor.error or "Model is not loaded."}), 503

    image_bytes = file.read()
    if not image_bytes:
        return jsonify({"error": "The uploaded file is empty."}), 400

    try:
        result = predictor.predict(image_bytes)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 422

    # Save the image with a unique name, then log the prediction
    ext = secure_filename(file.filename).rsplit(".", 1)[-1].lower()
    filename = f"{uuid.uuid4().hex}.{ext}"
    with open(os.path.join(config.UPLOAD_DIR, filename), "wb") as fh:
        fh.write(image_bytes)

    result["id"] = save_prediction(filename, result)
    result["filename"] = filename
    return jsonify(result)


@app.get("/api/diseases")
def diseases():
    items = list_diseases()
    return jsonify({"count": len(items), "diseases": items})


@app.get("/api/history")
def history():
    limit = request.args.get("limit", default=50, type=int)
    limit = max(1, min(limit, 500))
    return jsonify({"history": get_history(limit)})


@app.delete("/api/history")
def delete_history():
    for name in get_filenames():
        try:
            os.remove(os.path.join(config.UPLOAD_DIR, name))
        except OSError:
            pass
    removed = clear_history()
    return jsonify({"message": "History cleared.", "removed": removed})


@app.get("/api/stats")
def stats():
    return jsonify(get_stats())


@app.get("/api/uploads/<path:filename>")
def uploaded_file(filename):
    return send_from_directory(config.UPLOAD_DIR, secure_filename(filename))


# ------------------------------------------------------------------ frontend
# If the React app has been built (npm run build), Flask serves it too,
# so the whole project can run from a single command / server.
def _serve_frontend(path):
    if os.path.isdir(FRONTEND_DIST):
        target = os.path.join(FRONTEND_DIST, path)
        if path and os.path.isfile(target):
            return send_from_directory(FRONTEND_DIST, path)
        return send_from_directory(FRONTEND_DIST, "index.html")
    return jsonify(
        {
            "message": "LeafScan API is running. Start the React app "
                       "(cd frontend && npm run dev) and open http://localhost:5173",
            "endpoints": ["/api/health", "/api/predict", "/api/diseases",
                          "/api/history", "/api/stats"],
        }
    )


@app.get("/")
@app.get("/<path:path>")
def frontend(path=""):
    if path.startswith("api/"):
        return jsonify({"error": "Endpoint not found."}), 404
    return _serve_frontend(path)


if __name__ == "__main__":
    print(f"[INFO] LeafScan API on http://localhost:{config.PORT}")
    app.run(host=config.HOST, port=config.PORT, debug=config.DEBUG)
