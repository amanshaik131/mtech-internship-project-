"""
Disease knowledge base for the 38 PlantVillage classes.

Each entry gives a description, the cause, symptoms, treatment and
prevention. Class keys match the dataset folder names exactly.
Advice is general guidance; users should follow local agricultural
extension recommendations and pesticide labels.
"""
from utils.preprocess import format_label


def _d(description, cause, symptoms, treatment, prevention):
    return {
        "description": description,
        "cause": cause,
        "symptoms": symptoms,
        "treatment": treatment,
        "prevention": prevention,
    }


def _healthy(plant):
    return _d(
        f"The {plant} leaf looks healthy. No signs of disease were detected.",
        "Not applicable - no pathogen detected.",
        ["Uniform green colour", "No spots, lesions, mould or curling"],
        ["No treatment needed"],
        [
            "Keep watering and fertilising on a regular schedule",
            "Inspect leaves weekly so problems are caught early",
            "Remove weeds and fallen debris around the plant",
        ],
    )


DISEASE_INFO = {
    # ------------------------------------------------------------------ Apple
    "Apple___Apple_scab": _d(
        "A common fungal disease of apple that damages leaves and fruit.",
        "Fungus Venturia inaequalis; spreads in cool, wet spring weather.",
        ["Olive-green to black velvety spots on leaves", "Leaves curl and yellow",
         "Early leaf drop", "Dark, cracked scabs on fruit"],
        ["Apply fungicides such as captan or mancozeb at bud break",
         "Remove and destroy infected leaves"],
        ["Plant scab-resistant varieties", "Rake and destroy fallen leaves in autumn",
         "Prune to improve air circulation"],
    ),
    "Apple___Black_rot": _d(
        "A fungal disease causing leaf spots, fruit rot and branch cankers.",
        "Fungus Botryosphaeria obtusa; survives in dead wood and mummified fruit.",
        ["Purple spots that enlarge into 'frog-eye' lesions with tan centres",
         "Brown rot on fruit that turns black and shrivels",
         "Sunken cankers on branches"],
        ["Prune out cankers and dead wood", "Remove mummified fruit from the tree",
         "Apply captan or sulphur-based fungicides during the season"],
        ["Keep the orchard clean of dead wood and fallen fruit",
         "Avoid wounding the bark", "Maintain good tree vigour"],
    ),
    "Apple___Cedar_apple_rust": _d(
        "A rust disease that needs both apple and juniper (cedar) trees to complete its life cycle.",
        "Fungus Gymnosporangium juniperi-virginianae; spores blow from nearby junipers in spring.",
        ["Bright yellow-orange spots on the upper leaf surface",
         "Small tube-like structures on the leaf underside",
         "Premature leaf drop in severe cases"],
        ["Apply myclobutanil or mancozeb from pink bud stage to early summer",
         "Remove heavily infected leaves"],
        ["Plant rust-resistant apple varieties",
         "Remove nearby juniper/cedar hosts where practical"],
    ),
    "Apple___healthy": _healthy("apple"),
    # -------------------------------------------------------------- Blueberry
    "Blueberry___healthy": _healthy("blueberry"),
    # ----------------------------------------------------------------- Cherry
    "Cherry_(including_sour)___Powdery_mildew": _d(
        "A fungal disease that covers cherry leaves with white powdery growth.",
        "Fungus Podosphaera clandestina; favoured by warm days, cool nights and high humidity.",
        ["White powdery patches on young leaves", "Leaves curl upward and become distorted",
         "Stunted shoot growth"],
        ["Spray sulphur, potassium bicarbonate or myclobutanil at first sign",
         "Prune and destroy infected shoots"],
        ["Prune for open canopy and airflow", "Avoid excess nitrogen fertiliser",
         "Water at the base, not over the leaves"],
    ),
    "Cherry_(including_sour)___healthy": _healthy("cherry"),
    # ------------------------------------------------------------------- Corn
    "Corn_(maize)___Cercospora_leaf_spot Gray_leaf_spot": _d(
        "Gray leaf spot is one of the most yield-limiting foliar diseases of maize.",
        "Fungus Cercospora zeae-maydis; survives in crop residue, favoured by warm humid weather.",
        ["Narrow, rectangular grey to tan lesions between leaf veins",
         "Lesions merge and kill large leaf areas", "Lower leaves affected first"],
        ["Apply strobilurin or triazole fungicides at early disease stage",
         "Scout fields regularly from tasselling"],
        ["Grow resistant hybrids", "Rotate with non-host crops",
         "Plough under or manage infected residue"],
    ),
    "Corn_(maize)___Common_rust_": _d(
        "A rust disease producing powdery reddish-brown pustules on maize leaves.",
        "Fungus Puccinia sorghi; spores are carried long distances by wind.",
        ["Small, oval, cinnamon-brown pustules on both leaf surfaces",
         "Pustules turn dark brown-black later in the season",
         "Yellowing of heavily infected leaves"],
        ["Apply triazole or strobilurin fungicide if infection is heavy before tasselling"],
        ["Plant rust-resistant hybrids", "Sow early to avoid peak spore periods"],
    ),
    "Corn_(maize)___Northern_Leaf_Blight": _d(
        "A foliar disease that forms long cigar-shaped lesions and reduces grain fill.",
        "Fungus Exserohilum turcicum; favoured by moderate temperatures and heavy dew.",
        ["Long (2.5-15 cm) grey-green to tan cigar-shaped lesions",
         "Lesions start on lower leaves and move upward",
         "Dark spore growth on lesions in humid weather"],
        ["Apply fungicide (e.g. propiconazole, azoxystrobin) when lesions appear before silking"],
        ["Use resistant hybrids", "Rotate crops and manage residue",
         "Avoid continuous maize planting"],
    ),
    "Corn_(maize)___healthy": _healthy("corn"),
    # ------------------------------------------------------------------ Grape
    "Grape___Black_rot": _d(
        "A serious fungal disease of grapes that can destroy the entire crop in wet seasons.",
        "Fungus Guignardia bidwellii; overwinters in mummified berries and canes.",
        ["Small tan leaf spots with dark brown borders and black dots",
         "Berries turn brown, then shrivel into hard black mummies"],
        ["Apply mancozeb, captan or myclobutanil from bud break to fruit set",
         "Remove infected leaves and berries"],
        ["Remove all mummified fruit during dormant pruning",
         "Train vines for good air flow and sun exposure"],
    ),
    "Grape___Esca_(Black_Measles)": _d(
        "A complex trunk disease of grapevines that causes leaf striping and berry spotting.",
        "Wood-decaying fungi such as Phaeomoniella chlamydospora and Phaeoacremonium species, entering through pruning wounds.",
        ["'Tiger-stripe' pattern - yellow or red bands between leaf veins",
         "Small dark spots on berries", "Sudden wilting and dieback of shoots"],
        ["No curative spray exists; cut out infected wood well below symptoms",
         "Remove severely affected vines"],
        ["Prune in dry weather and protect large cuts with wound sealant",
         "Use clean, disinfected pruning tools", "Plant certified healthy material"],
    ),
    "Grape___Leaf_blight_(Isariopsis_Leaf_Spot)": _d(
        "A leaf spot disease that causes early defoliation of grapevines.",
        "Fungus Pseudocercospora vitis (Isariopsis clavispora); favoured by warm, humid conditions.",
        ["Irregular dark red-brown spots on leaves", "Spots merge into large dead patches",
         "Premature leaf drop"],
        ["Apply copper-based or mancozeb fungicides", "Remove infected leaves"],
        ["Improve canopy ventilation by pruning", "Avoid overhead irrigation",
         "Clear fallen leaves from the vineyard"],
    ),
    "Grape___healthy": _healthy("grape"),
    # ----------------------------------------------------------------- Orange
    "Orange___Haunglongbing_(Citrus_greening)": _d(
        "Huanglongbing (citrus greening) is a deadly bacterial disease of citrus with no known cure.",
        "Bacterium Candidatus Liberibacter asiaticus, spread by the Asian citrus psyllid insect.",
        ["Blotchy, asymmetric yellow mottling of leaves", "Small, lopsided, bitter fruit that stays green",
         "Twig dieback and overall decline of the tree"],
        ["No cure - remove and destroy infected trees to protect others",
         "Control psyllids with recommended insecticides",
         "Nutritional sprays can prolong productivity of mildly affected trees"],
        ["Plant certified disease-free nursery stock",
         "Monitor and control psyllid populations",
         "Inspect trees regularly and report suspected cases"],
    ),
    # ------------------------------------------------------------------ Peach
    "Peach___Bacterial_spot": _d(
        "A bacterial disease of peach that spots leaves and fruit and causes defoliation.",
        "Bacterium Xanthomonas arboricola pv. pruni; spreads by wind-driven rain.",
        ["Small water-soaked spots that turn purple-brown",
         "Spot centres fall out leaving a 'shot-hole' look",
         "Pitted, cracked spots on fruit"],
        ["Apply copper sprays during dormancy and oxytetracycline in season where permitted"],
        ["Plant resistant varieties", "Avoid excessive nitrogen",
         "Choose sites protected from strong winds"],
    ),
    "Peach___healthy": _healthy("peach"),
    # ----------------------------------------------------------- Bell pepper
    "Pepper,_bell___Bacterial_spot": _d(
        "A bacterial disease that causes leaf spots, leaf drop and scabby fruit in pepper.",
        "Bacteria Xanthomonas species; carried on seed and spread by splashing water.",
        ["Small water-soaked spots that turn brown with yellow halos",
         "Leaves yellow and drop", "Raised scab-like spots on fruit"],
        ["Spray copper-based bactericides combined with mancozeb",
         "Remove and destroy infected plants"],
        ["Use certified disease-free seed and transplants",
         "Rotate crops for 2-3 years", "Avoid overhead watering and working with wet plants"],
    ),
    "Pepper,_bell___healthy": _healthy("bell pepper"),
    # ----------------------------------------------------------------- Potato
    "Potato___Early_blight": _d(
        "A common fungal disease of potato that reduces leaf area and yield.",
        "Fungus Alternaria solani; favoured by warm weather alternating with wet periods.",
        ["Brown spots with concentric rings ('target' pattern) on older leaves",
         "Yellowing around the spots", "Leaves dry up and fall"],
        ["Apply chlorothalonil, mancozeb or azoxystrobin fungicides",
         "Remove infected lower leaves"],
        ["Rotate crops (avoid potato/tomato for 2-3 years)",
         "Maintain good plant nutrition", "Destroy crop debris after harvest"],
    ),
    "Potato___Late_blight": _d(
        "A destructive disease (cause of the Irish famine) that can wipe out a crop within days.",
        "Water mould Phytophthora infestans; spreads rapidly in cool, moist weather.",
        ["Large, dark, water-soaked patches on leaves",
         "White fuzzy growth on the leaf underside", "Brown rot in tubers"],
        ["Apply metalaxyl-mancozeb, cymoxanil or chlorothalonil immediately",
         "Remove and destroy infected plants - do not compost"],
        ["Plant certified disease-free seed tubers", "Choose resistant varieties",
         "Avoid overhead irrigation and ensure good drainage"],
    ),
    "Potato___healthy": _healthy("potato"),
    # -------------------------------------------------------------- Raspberry
    "Raspberry___healthy": _healthy("raspberry"),
    # ---------------------------------------------------------------- Soybean
    "Soybean___healthy": _healthy("soybean"),
    # ----------------------------------------------------------------- Squash
    "Squash___Powdery_mildew": _d(
        "A very common fungal disease of squash and other cucurbits.",
        "Fungi Podosphaera xanthii and Erysiphe cichoracearum; thrives in warm, dry weather with humid nights.",
        ["White powdery spots on upper leaf surfaces", "Spots spread to cover the whole leaf",
         "Leaves yellow, wither and die early"],
        ["Spray sulphur, potassium bicarbonate or neem oil at first sign",
         "Remove badly infected leaves"],
        ["Plant resistant varieties", "Space plants for good airflow",
         "Avoid excess nitrogen fertiliser"],
    ),
    # ------------------------------------------------------------- Strawberry
    "Strawberry___Leaf_scorch": _d(
        "A fungal leaf disease that weakens strawberry plants and reduces yield.",
        "Fungus Diplocarpon earlianum; spreads by splashing water.",
        ["Many small, irregular purple spots on leaves",
         "Spots merge, leaf edges look burnt or scorched", "Leaves dry and curl"],
        ["Remove infected leaves", "Apply captan or myclobutanil fungicides"],
        ["Use disease-free transplants", "Use drip irrigation instead of sprinklers",
         "Renovate beds after harvest and avoid overcrowding"],
    ),
    "Strawberry___healthy": _healthy("strawberry"),
    # ----------------------------------------------------------------- Tomato
    "Tomato___Bacterial_spot": _d(
        "A bacterial disease causing leaf spots and blemished fruit in tomato.",
        "Bacteria Xanthomonas species; spread by infected seed and splashing water.",
        ["Small, dark, greasy-looking spots on leaves", "Leaves yellow and drop",
         "Raised scabby spots on fruit"],
        ["Spray copper-based bactericides with mancozeb", "Remove infected plant parts"],
        ["Use certified disease-free seed", "Rotate crops", "Avoid overhead watering"],
    ),
    "Tomato___Early_blight": _d(
        "A common fungal disease that causes leaf spotting and defoliation in tomato.",
        "Fungus Alternaria solani; favoured by warm, humid weather.",
        ["Brown spots with concentric rings on older leaves",
         "Yellow tissue around spots", "Dark lesions on stems near the soil"],
        ["Apply chlorothalonil, mancozeb or copper fungicides",
         "Remove infected lower leaves"],
        ["Mulch to stop soil splashing onto leaves", "Stake plants and prune for airflow",
         "Rotate crops every 2-3 years"],
    ),
    "Tomato___Late_blight": _d(
        "A fast-spreading, highly destructive disease of tomato and potato.",
        "Water mould Phytophthora infestans; spreads in cool, wet weather.",
        ["Large, irregular grey-green water-soaked patches on leaves",
         "White mould on the leaf underside", "Firm brown rot on fruit"],
        ["Apply metalaxyl-mancozeb or chlorothalonil immediately",
         "Remove and destroy infected plants"],
        ["Plant resistant varieties", "Keep foliage dry and space plants well",
         "Do not plant near potatoes"],
    ),
    "Tomato___Leaf_Mold": _d(
        "A fungal disease mostly seen in greenhouses and humid conditions.",
        "Fungus Passalora fulva (Fulvia fulva); thrives in humidity above 85%.",
        ["Pale green to yellow spots on the upper leaf surface",
         "Olive-green to brown velvety mould on the underside", "Leaves wither and drop"],
        ["Improve ventilation and reduce humidity",
         "Apply chlorothalonil or copper fungicides", "Remove infected leaves"],
        ["Plant resistant varieties", "Space plants and prune lower leaves",
         "Water early in the day at the base"],
    ),
    "Tomato___Septoria_leaf_spot": _d(
        "A fungal disease that causes many small spots and severe defoliation in tomato.",
        "Fungus Septoria lycopersici; survives on crop debris and spreads by splashing water.",
        ["Many small circular spots with dark borders and grey centres",
         "Tiny black dots in the centre of spots", "Lower leaves yellow and fall first"],
        ["Remove infected leaves", "Apply chlorothalonil, mancozeb or copper fungicides"],
        ["Rotate crops", "Mulch the soil surface", "Avoid wetting the leaves"],
    ),
    "Tomato___Spider_mites Two-spotted_spider_mite": _d(
        "Damage caused by tiny sap-sucking mites, common in hot, dry conditions.",
        "Two-spotted spider mite (Tetranychus urticae).",
        ["Fine yellow or white speckling (stippling) on leaves",
         "Fine webbing on the leaf underside", "Leaves turn bronze, dry and drop"],
        ["Spray water on the leaf underside to dislodge mites",
         "Apply insecticidal soap, neem oil or a recommended miticide"],
        ["Keep plants well watered - stressed plants are more attacked",
         "Encourage natural predators such as predatory mites and ladybirds",
         "Avoid broad-spectrum insecticides that kill predators"],
    ),
    "Tomato___Target_Spot": _d(
        "A fungal disease causing target-like spots on leaves, stems and fruit.",
        "Fungus Corynespora cassiicola; favoured by warm, humid weather.",
        ["Brown spots with concentric rings and yellow halos",
         "Spots merge and leaves collapse", "Sunken spots on fruit"],
        ["Apply chlorothalonil, mancozeb or azoxystrobin fungicides",
         "Remove infected leaves"],
        ["Improve air circulation", "Rotate crops and remove crop debris",
         "Avoid overhead irrigation"],
    ),
    "Tomato___Tomato_Yellow_Leaf_Curl_Virus": _d(
        "A damaging viral disease that stunts tomato plants and sharply reduces yield.",
        "Tomato yellow leaf curl virus (TYLCV), transmitted by the silverleaf whitefly.",
        ["Leaves curl upward and become small and cupped",
         "Yellowing of leaf edges", "Stunted plants with few flowers and fruit"],
        ["No cure - remove and destroy infected plants",
         "Control whiteflies with yellow sticky traps, neem oil or recommended insecticides"],
        ["Plant TYLCV-resistant varieties", "Use insect-proof nets in nurseries",
         "Remove weeds that host whiteflies"],
    ),
    "Tomato___Tomato_mosaic_virus": _d(
        "A highly contagious viral disease spread by touch, tools and seed.",
        "Tomato mosaic virus (ToMV); survives for long periods in plant debris and on hands.",
        ["Light and dark green mosaic pattern on leaves",
         "Leaves become distorted or fern-like", "Uneven ripening of fruit"],
        ["No cure - remove and destroy infected plants",
         "Disinfect tools and wash hands after handling plants"],
        ["Use certified virus-free seed and resistant varieties",
         "Avoid tobacco use near plants", "Control weeds and clean up crop debris"],
    ),
    "Tomato___healthy": _healthy("tomato"),
}

DEFAULT_INFO = _d(
    "No detailed information is available for this class.",
    "Unknown.",
    ["Consult a local agricultural expert"],
    ["Consult a local agricultural expert"],
    ["Follow good field hygiene and crop rotation"],
)


def get_disease_info(class_name: str) -> dict:
    return DISEASE_INFO.get(class_name, DEFAULT_INFO)


def list_diseases() -> list:
    """All classes with readable labels and information, in a stable order."""
    return [
        {"class_name": name, **format_label(name), "info": info}
        for name, info in DISEASE_INFO.items()
    ]
