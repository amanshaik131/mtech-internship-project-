"""
SQLite layer for prediction history.

One row is stored per prediction. SQLite is file based, so no separate
database server is needed.
"""
import sqlite3
from contextlib import closing
from datetime import datetime

from config import DATABASE_PATH

SCHEMA = """
CREATE TABLE IF NOT EXISTS predictions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    filename    TEXT    NOT NULL,
    plant       TEXT    NOT NULL,
    disease     TEXT    NOT NULL,
    is_healthy  INTEGER NOT NULL,
    confidence  REAL    NOT NULL,
    created_at  TEXT    NOT NULL
)
"""


def _connect():
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with closing(_connect()) as conn, conn:
        conn.execute(SCHEMA)


def save_prediction(filename: str, result: dict) -> int:
    """Insert one prediction and return its new id."""
    with closing(_connect()) as conn, conn:
        cursor = conn.execute(
            "INSERT INTO predictions "
            "(filename, plant, disease, is_healthy, confidence, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (
                filename,
                result["plant"],
                result["disease"],
                int(result["is_healthy"]),
                float(result["confidence"]),
                datetime.now().isoformat(timespec="seconds"),
            ),
        )
        return cursor.lastrowid


def get_history(limit: int = 50) -> list:
    with closing(_connect()) as conn:
        rows = conn.execute(
            "SELECT * FROM predictions ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
    return [
        {**dict(row), "is_healthy": bool(row["is_healthy"])} for row in rows
    ]


def get_filenames() -> list:
    with closing(_connect()) as conn:
        return [r[0] for r in conn.execute("SELECT filename FROM predictions")]


def clear_history() -> int:
    """Delete every row. Returns the number of rows removed."""
    with closing(_connect()) as conn, conn:
        return conn.execute("DELETE FROM predictions").rowcount


def get_stats() -> dict:
    with closing(_connect()) as conn:
        row = conn.execute(
            "SELECT COUNT(*) AS total, "
            "COALESCE(SUM(is_healthy), 0) AS healthy, "
            "COALESCE(AVG(confidence), 0) AS avg_conf "
            "FROM predictions"
        ).fetchone()
    total, healthy = row["total"], row["healthy"]
    return {
        "total": total,
        "healthy": healthy,
        "diseased": total - healthy,
        "average_confidence": round(row["avg_conf"], 4),
    }
