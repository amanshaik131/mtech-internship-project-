"""
Image preprocessing helpers shared by training and inference.

Normalisation (0-255 -> -1..+1) is built into the model itself as a
Rescaling layer, so here we only convert to RGB, resize and batch.
"""
import io

import numpy as np
from PIL import Image, ImageOps

from config import IMAGE_SIZE


def load_image(image_bytes: bytes) -> Image.Image:
    """Open raw bytes as an RGB PIL image. Raises ValueError if unreadable."""
    try:
        image = Image.open(io.BytesIO(image_bytes))
        image.load()
    except Exception as exc:  # PIL raises many different error types
        raise ValueError("Could not process image. Is it a valid picture?") from exc
    # Respect the camera's orientation flag (phone photos are often rotated)
    image = ImageOps.exif_transpose(image)
    return image.convert("RGB")


def preprocess_image(image: Image.Image) -> np.ndarray:
    """Resize a PIL image and return a float32 batch of shape (1, 224, 224, 3)."""
    image = image.resize(IMAGE_SIZE, Image.BILINEAR)
    array = np.asarray(image, dtype=np.float32)
    return np.expand_dims(array, axis=0)


# Readable names for folder names that do not convert cleanly
PLANT_OVERRIDES = {
    "Cherry_(including_sour)": "Cherry",
    "Corn_(maize)": "Corn (Maize)",
    "Pepper,_bell": "Bell Pepper",
}
DISPLAY_OVERRIDES = {
    "Cercospora_leaf_spot Gray_leaf_spot": "Cercospora Leaf Spot (Gray Leaf Spot)",
    "Haunglongbing_(Citrus_greening)": "Huanglongbing (Citrus Greening)",
    "Spider_mites Two-spotted_spider_mite": "Spider Mites (Two-spotted)",
    "Tomato_Yellow_Leaf_Curl_Virus": "Yellow Leaf Curl Virus",
    "Tomato_mosaic_virus": "Mosaic Virus",
}


def format_label(class_name: str) -> dict:
    """
    Turn a PlantVillage folder name into readable parts.

    "Tomato___Late_blight"            -> plant "Tomato", disease "Late Blight"
    "Corn_(maize)___Common_rust_"     -> plant "Corn (Maize)", disease "Common Rust"
    "Pepper,_bell___healthy"          -> plant "Bell Pepper", disease "Healthy"
    """
    plant, _, disease = class_name.partition("___")

    def clean(text: str) -> str:
        text = text.replace("_", " ").strip()
        text = " ".join(text.split())
        return " ".join(w[:1].upper() + w[1:] if w else w for w in text.split(" "))

    plant_name = PLANT_OVERRIDES.get(plant, clean(plant))
    disease_name = DISPLAY_OVERRIDES.get(disease, clean(disease) or "Unknown")
    is_healthy = disease.lower() == "healthy"
    return {
        "plant": plant_name,
        "disease": "Healthy" if is_healthy else disease_name,
        "is_healthy": is_healthy,
    }
