"""Helper modules: preprocessing, prediction and database."""
