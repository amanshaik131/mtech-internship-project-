"""
Loads the trained CNN once and turns an image into a prediction.

If the model file is missing the API still starts; `ready` is False and
`error` explains what to do, which the /api/health endpoint reports.
"""
import json
import os
import time

import numpy as np

from config import CLASS_NAMES_PATH, CONFIDENCE_THRESHOLD, MODEL_PATH, TOP_K
from disease_info import get_disease_info
from utils.preprocess import format_label, load_image, preprocess_image


class Predictor:
    def __init__(self):
        self.model = None
        self.class_names = []
        self.ready = False
        self.error = None
        self.load()

    # ------------------------------------------------------------ loading
    def load(self):
        if not os.path.exists(MODEL_PATH):
            self.error = (
                "Model file not found. Train the model with "
                "'python train.py --data <train> --val <valid>' "
                "or copy plant_disease_model.h5 into backend/model/."
            )
            print(f"[WARN] {self.error}")
            return
        if not os.path.exists(CLASS_NAMES_PATH):
            self.error = "class_names.json not found in backend/model/."
            print(f"[WARN] {self.error}")
            return
        try:
            import tensorflow as tf  # imported lazily so the API starts fast

            print(f"[INFO] Loading model from {MODEL_PATH} ...")
            self.model = tf.keras.models.load_model(MODEL_PATH, compile=False)
            with open(CLASS_NAMES_PATH, encoding="utf-8") as fh:
                self.class_names = json.load(fh)

            outputs = self.model.output_shape[-1]
            if outputs != len(self.class_names):
                raise ValueError(
                    f"Model has {outputs} outputs but class_names.json "
                    f"lists {len(self.class_names)} classes."
                )
            # Warm-up run so the first real request is not slow
            self.model.predict(np.zeros((1, 224, 224, 3), np.float32), verbose=0)
            self.ready = True
            self.error = None
            print(f"[INFO] Model ready ({len(self.class_names)} classes).")
        except Exception as exc:
            self.error = f"Failed to load model: {exc}"
            print(f"[ERROR] {self.error}")

    # ------------------------------------------------------------ inference
    def predict(self, image_bytes: bytes, top_k: int = TOP_K) -> dict:
        """Raise ValueError if the image cannot be read."""
        image = load_image(image_bytes)
        batch = preprocess_image(image)

        start = time.perf_counter()
        probabilities = self.model.predict(batch, verbose=0)[0]
        elapsed_ms = (time.perf_counter() - start) * 1000

        top_indices = np.argsort(probabilities)[::-1][:top_k]
        best_class = self.class_names[int(top_indices[0])]
        confidence = float(probabilities[top_indices[0]])
        label = format_label(best_class)

        top_predictions = []
        for idx in top_indices:
            name = self.class_names[int(idx)]
            top_predictions.append(
                {
                    "class_name": name,
                    **format_label(name),
                    "confidence": round(float(probabilities[idx]), 4),
                }
            )

        return {
            "class_name": best_class,
            **label,
            "confidence": round(confidence, 4),
            "uncertain": confidence < CONFIDENCE_THRESHOLD,
            "top_predictions": top_predictions,
            "info": get_disease_info(best_class),
            "inference_ms": round(elapsed_ms, 1),
        }
