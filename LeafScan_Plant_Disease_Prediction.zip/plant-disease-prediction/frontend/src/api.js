// Every call to the Flask backend lives here. A single request() helper
// handles network failures and error messages so components stay simple.
export const API_URL = (import.meta.env.VITE_API_URL || "").replace(/\/$/, "");

async function request(path, options = {}) {
  let response;
  try {
    response = await fetch(`${API_URL}${path}`, options);
  } catch {
    throw new Error("Cannot reach the server. Make sure the backend is running (python app.py).");
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}

export const getHealth = () => request("/api/health");

export const predictDisease = (file) => {
  const formData = new FormData();
  formData.append("image", file);
  return request("/api/predict", { method: "POST", body: formData });
};

export const getDiseases = () => request("/api/diseases");
export const getHistory = (limit = 50) => request(`/api/history?limit=${limit}`);
export const clearHistory = () => request("/api/history", { method: "DELETE" });
export const getStats = () => request("/api/stats");
export const imageUrl = (filename) => `${API_URL}/api/uploads/${filename}`;
