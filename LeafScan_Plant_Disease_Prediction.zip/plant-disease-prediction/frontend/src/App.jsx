import { useCallback, useEffect, useState } from "react";
import { getHealth, predictDisease } from "./api.js";
import Header from "./components/Header.jsx";
import UploadSection from "./components/UploadSection.jsx";
import ResultCard from "./components/ResultCard.jsx";
import History from "./components/History.jsx";
import DiseaseLibrary from "./components/DiseaseLibrary.jsx";
import About from "./components/About.jsx";

const PAGES = ["detect", "history", "library", "about"];
const pageFromHash = () => {
  const p = window.location.hash.replace("#/", "");
  return PAGES.includes(p) ? p : "detect";
};

export default function App() {
  const [page, setPage] = useState(pageFromHash);
  const [health, setHealth] = useState({ state: "checking" });
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // ---- backend health (re-checked every 15 s so the badge stays honest)
  const checkHealth = useCallback(async () => {
    try {
      const data = await getHealth();
      setHealth({ state: data.model_loaded ? "ready" : "nomodel", message: data.message });
    } catch {
      setHealth({ state: "offline" });
    }
  }, []);

  useEffect(() => {
    checkHealth();
    const id = setInterval(checkHealth, 15000);
    return () => clearInterval(id);
  }, [checkHealth]);

  // ---- simple hash routing so the browser back button works
  useEffect(() => {
    const onHash = () => setPage(pageFromHash());
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  const navigate = (p) => {
    window.location.hash = `#/${p}`;
    setPage(p);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSelect = (selected) => {
    if (preview) URL.revokeObjectURL(preview);
    setFile(selected);
    setPreview(selected ? URL.createObjectURL(selected) : "");
    setResult(null);
    setError("");
  };

  const handleAnalyze = async () => {
    if (!file) return;
    setLoading(true);
    setError("");
    setResult(null);
    try {
      setResult(await predictDisease(file));
    } catch (err) {
      setError(err.message);
      checkHealth();
    } finally {
      setLoading(false);
    }
  };

  const reset = () => handleSelect(null);

  return (
    <div className="app">
      <Header page={page} onNavigate={navigate} health={health} />

      <main className="container">
        {page === "detect" && (
          <>
            {!result && (
              <section className="hero">
                <span className="eyebrow">AI-powered crop health</span>
                <h1>Detect plant diseases in seconds</h1>
                <p>
                  Upload a photo of a plant leaf. Our deep learning model identifies the disease
                  and suggests treatment.
                </p>
              </section>
            )}

            {health.state === "offline" && (
              <div className="banner banner-error" role="alert">
                <strong>Server offline.</strong> Start the backend with <code>python app.py</code> in
                the <code>backend</code> folder, then try again.
                <button className="link-btn" onClick={checkHealth}>Retry</button>
              </div>
            )}
            {health.state === "nomodel" && (
              <div className="banner banner-warn" role="alert">
                <strong>Model not loaded.</strong> {health.message}
              </div>
            )}

            <div className={result ? "detect-grid has-result" : "detect-grid"}>
              <UploadSection
                file={file}
                preview={preview}
                loading={loading}
                error={error}
                compact={!!result}
                disabled={health.state !== "ready"}
                onSelect={handleSelect}
                onAnalyze={handleAnalyze}
                onReset={reset}
              />
              {result && <ResultCard result={result} onReset={reset} />}
            </div>
          </>
        )}

        {page === "history" && <History onNavigate={navigate} />}
        {page === "library" && <DiseaseLibrary />}
        {page === "about" && <About />}
      </main>

      <footer className="footer">
        <span>Plant Disease Prediction using AI</span>
        <span className="dot">·</span>
        <span>Internship Project</span>
        <span className="dot">·</span>
        <span>React + Flask + TensorFlow</span>
      </footer>
    </div>
  );
}
