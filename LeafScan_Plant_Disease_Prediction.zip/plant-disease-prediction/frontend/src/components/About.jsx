const STEPS = [
  { title: "Upload", text: "The user uploads or captures a leaf photo in the React web app." },
  { title: "Preprocess", text: "The Flask API resizes the image to 224×224 and normalises pixels." },
  { title: "Predict", text: "A MobileNetV2 CNN, fine-tuned on PlantVillage, outputs probabilities for 38 classes." },
  { title: "Advise", text: "The top class is matched to a knowledge base of causes, treatments and prevention." },
];

const STACK = [
  ["Frontend", "React 18 + Vite"],
  ["Backend", "Python, Flask REST API, SQLite"],
  ["AI model", "TensorFlow / Keras, MobileNetV2 transfer learning"],
  ["Dataset", "PlantVillage (~87,000 augmented images, 14 crops, 38 classes)"],
];

const CROPS = ["Apple", "Blueberry", "Cherry", "Corn", "Grape", "Orange", "Peach",
  "Bell Pepper", "Potato", "Raspberry", "Soybean", "Squash", "Strawberry", "Tomato"];

export default function About() {
  return (
    <section className="about">
      <h1>About this project</h1>
      <p className="lead">
        <strong>Plant Disease Prediction using AI</strong> helps farmers and gardeners spot crop
        diseases early from a single leaf photo. Early detection reduces crop loss and avoids
        unnecessary pesticide use.
      </p>

      <div className="about-stats">
        <div><strong>38</strong><span>classes</span></div>
        <div><strong>14</strong><span>crops</span></div>
        <div><strong>224²</strong><span>input pixels</span></div>
        <div><strong>&lt;1 s</strong><span>per prediction</span></div>
      </div>

      <h2>How it works</h2>
      <div className="steps">
        {STEPS.map((s, i) => (
          <div key={s.title} className="card step">
            <span className="step-num">{i + 1}</span>
            <h3>{s.title}</h3>
            <p>{s.text}</p>
          </div>
        ))}
      </div>

      <h2>Supported crops</h2>
      <div className="chips static">{CROPS.map((c) => <span key={c} className="chip">{c}</span>)}</div>

      <h2>Tech stack</h2>
      <div className="card stack">
        <ul>{STACK.map(([k, v]) => <li key={k}><strong>{k}:</strong> {v}</li>)}</ul>
      </div>

      <h2>Limitations</h2>
      <div className="card stack">
        <ul>
          <li>Trained on lab images with plain backgrounds; field photos with clutter may score lower.</li>
          <li>Only the 38 trained classes can be recognised. Other plants are mapped to the closest class, so low-confidence results are flagged.</li>
          <li>Results are guidance only and do not replace advice from an agricultural expert.</li>
        </ul>
      </div>
    </section>
  );
}
