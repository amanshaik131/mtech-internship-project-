import { useEffect, useMemo, useState } from "react";
import { getDiseases } from "../api.js";

export default function DiseaseLibrary() {
  const [items, setItems] = useState([]);
  const [query, setQuery] = useState("");
  const [crop, setCrop] = useState("All");
  const [filter, setFilter] = useState("all");
  const [open, setOpen] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getDiseases()
      .then((d) => setItems(d.diseases))
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  const crops = useMemo(() => ["All", ...new Set(items.map((i) => i.plant))], [items]);

  const shown = items.filter((i) => {
    const q = query.trim().toLowerCase();
    const matchesQuery = !q || `${i.plant} ${i.disease}`.toLowerCase().includes(q);
    const matchesCrop = crop === "All" || i.plant === crop;
    const matchesType = filter === "all" || (filter === "healthy" ? i.is_healthy : !i.is_healthy);
    return matchesQuery && matchesCrop && matchesType;
  });

  return (
    <section>
      <div className="page-head">
        <div>
          <h1>Disease library</h1>
          <p className="muted">The model recognises {items.length || 38} classes from the PlantVillage dataset.</p>
        </div>
        <input className="search" type="search" placeholder="Search plant or disease…"
          value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Search diseases" />
      </div>

      <div className="filters">
        <div className="chips">
          {crops.map((c) => (
            <button key={c} className={crop === c ? "chip active" : "chip"} onClick={() => setCrop(c)}>{c}</button>
          ))}
        </div>
        <div className="segmented">
          {["all", "disease", "healthy"].map((f) => (
            <button key={f} className={filter === f ? "seg active" : "seg"} onClick={() => setFilter(f)}>
              {f[0].toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {error && <div className="alert alert-error">⚠️ {error}</div>}
      {loading && <div className="empty"><span className="spinner dark" /> Loading library…</div>}
      {!loading && !error && shown.length === 0 && (
        <div className="card empty">No matches for “{query}”.</div>
      )}

      <div className="library-grid">
        {shown.map((d) => {
          const isOpen = open === d.class_name;
          return (
            <article key={d.class_name} className={isOpen ? "card lib-card open" : "card lib-card"}>
              <button className="lib-head" onClick={() => setOpen(isOpen ? null : d.class_name)} aria-expanded={isOpen}>
                <div>
                  <div className="lib-plant">{d.plant}</div>
                  <div className="lib-name">{d.disease}</div>
                </div>
                <span className={d.is_healthy ? "pill pill-healthy" : "pill pill-disease"}>
                  {d.is_healthy ? "Healthy" : "Disease"}
                </span>
              </button>
              {isOpen && (
                <div className="lib-body">
                  <p>{d.info.description}</p>
                  {!d.is_healthy && <p><strong>Cause:</strong> {d.info.cause}</p>}
                  {!d.is_healthy && (
                    <>
                      <h4>Symptoms</h4>
                      <ul>{d.info.symptoms.map((s, i) => <li key={i}>{s}</li>)}</ul>
                      <h4>Treatment</h4>
                      <ul>{d.info.treatment.map((s, i) => <li key={i}>{s}</li>)}</ul>
                    </>
                  )}
                  <h4>Prevention</h4>
                  <ul>{d.info.prevention.map((s, i) => <li key={i}>{s}</li>)}</ul>
                </div>
              )}
            </article>
          );
        })}
      </div>
    </section>
  );
}
