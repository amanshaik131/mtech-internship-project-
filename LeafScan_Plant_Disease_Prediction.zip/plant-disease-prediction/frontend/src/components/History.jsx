import { useEffect, useState } from "react";
import { clearHistory, getHistory, getStats, imageUrl } from "../api.js";

const formatDate = (iso) =>
  new Date(iso).toLocaleString(undefined, {
    day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit",
  });

export default function History({ onNavigate }) {
  const [items, setItems] = useState([]);
  const [stats, setStats] = useState({ total: 0, healthy: 0, diseased: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [confirming, setConfirming] = useState(false);

  const load = async () => {
    setLoading(true);
    setError("");
    try {
      const [h, s] = await Promise.all([getHistory(100), getStats()]);
      setItems(h.history);
      setStats(s);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const handleClear = async () => {
    setConfirming(false);
    try {
      await clearHistory();
      await load();
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <section>
      <div className="page-head">
        <div>
          <h1>Prediction history</h1>
          <p className="muted">Every leaf you analyse is saved here.</p>
        </div>
        {items.length > 0 && (
          confirming ? (
            <div className="confirm">
              <span>Delete all {items.length} records?</span>
              <button className="btn btn-danger btn-sm" onClick={handleClear}>Yes, clear</button>
              <button className="btn btn-ghost btn-sm" onClick={() => setConfirming(false)}>Cancel</button>
            </div>
          ) : (
            <button className="btn btn-ghost" onClick={() => setConfirming(true)}>Clear history</button>
          )
        )}
      </div>

      <div className="stats">
        <div className="card stat"><div className="stat-num">{stats.total}</div><div className="stat-label">Total scans</div></div>
        <div className="card stat"><div className="stat-num green">{stats.healthy}</div><div className="stat-label">Healthy</div></div>
        <div className="card stat"><div className="stat-num red">{stats.diseased}</div><div className="stat-label">Diseased</div></div>
      </div>

      {error && <div className="alert alert-error">⚠️ {error}</div>}

      <div className="card table-card">
        {loading ? (
          <div className="empty"><span className="spinner dark" /> Loading history…</div>
        ) : items.length === 0 ? (
          <div className="empty">
            <div className="empty-icon">🍃</div>
            No predictions yet. Analyze a leaf to see it here.
            <button className="btn btn-primary btn-sm" onClick={() => onNavigate("detect")}>Analyze a leaf</button>
          </div>
        ) : (
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr><th>Image</th><th>Plant</th><th>Result</th><th>Confidence</th><th>Date &amp; time</th></tr>
              </thead>
              <tbody>
                {items.map((row) => (
                  <tr key={row.id}>
                    <td>
                      <img className="thumb" src={imageUrl(row.filename)} alt="" loading="lazy"
                        onError={(e) => { e.currentTarget.style.visibility = "hidden"; }} />
                    </td>
                    <td className="strong">{row.plant}</td>
                    <td>
                      <span className={row.is_healthy ? "pill pill-healthy" : "pill pill-disease"}>
                        {row.disease}
                      </span>
                    </td>
                    <td>
                      <div className="mini-bar"><span style={{ width: `${row.confidence * 100}%` }} /></div>
                      {(row.confidence * 100).toFixed(1)}%
                    </td>
                    <td className="muted nowrap">{formatDate(row.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </section>
  );
}
