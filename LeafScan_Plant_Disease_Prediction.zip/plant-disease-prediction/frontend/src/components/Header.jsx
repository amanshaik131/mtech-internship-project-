import { useState } from "react";

export const LeafIcon = ({ size = 26 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true">
    <path
      fill="currentColor"
      d="M20 3C10 3 4 8 4 16c0 1.6.4 3 1 4.2C6.6 15 10 11.8 15 10c-4 2.4-7 5.7-8.6 10.4 1.2.4 2.5.6 3.8.6C18 21 20 12.5 20 3Z"
    />
  </svg>
);

const LINKS = [
  { id: "detect", label: "Detect" },
  { id: "history", label: "History" },
  { id: "library", label: "Disease Library" },
  { id: "about", label: "About" },
];

const STATUS = {
  checking: { cls: "checking", text: "Connecting…" },
  ready: { cls: "ready", text: "Model ready" },
  nomodel: { cls: "warn", text: "Model not loaded" },
  offline: { cls: "offline", text: "Server offline" },
};

export default function Header({ page, onNavigate, health }) {
  const [open, setOpen] = useState(false);
  const status = STATUS[health.state] || STATUS.checking;

  const go = (id) => {
    setOpen(false);
    onNavigate(id);
  };

  return (
    <header className="header">
      <div className="container header-inner">
        <button className="brand" onClick={() => go("detect")} aria-label="LeafScan home">
          LeafScan
        </button>

        <nav className={open ? "nav open" : "nav"} aria-label="Main">
          {LINKS.map((l) => (
            <button
              key={l.id}
              className={page === l.id ? "nav-link active" : "nav-link"}
              aria-current={page === l.id ? "page" : undefined}
              onClick={() => go(l.id)}
            >
              {l.label}
            </button>
          ))}
        </nav>

        <div className="header-right">
          <span className={`status status-${status.cls}`} title={health.message || status.text}>
            <span className="status-dot" />
            {status.text}
          </span>
          <button
            className="menu-btn"
            aria-label="Toggle menu"
            aria-expanded={open}
            onClick={() => setOpen(!open)}
          >
            <span /><span /><span />
          </button>
        </div>
      </div>
    </header>
  );
}
