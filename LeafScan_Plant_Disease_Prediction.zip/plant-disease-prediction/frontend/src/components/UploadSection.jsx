import { useEffect, useRef, useState } from "react";

const TYPES = ["image/jpeg", "image/png", "image/webp"];
const MAX_SIZE = 10 * 1024 * 1024;

const formatSize = (bytes) =>
  bytes > 1024 * 1024 ? `${(bytes / 1024 / 1024).toFixed(1)} MB` : `${Math.round(bytes / 1024)} KB`;

export default function UploadSection({
  file, preview, loading, error, compact, disabled, onSelect, onAnalyze, onReset,
}) {
  const inputRef = useRef(null);
  const cameraRef = useRef(null);
  const [dragging, setDragging] = useState(false);
  const [localError, setLocalError] = useState("");

  // Validate in the browser before anything is sent to the server
  const selectFile = (selected) => {
    if (!selected) return;
    setLocalError("");
    if (!TYPES.includes(selected.type))
      return setLocalError("Please choose a JPG, PNG or WEBP image.");
    if (selected.size > MAX_SIZE)
      return setLocalError("Image is larger than 10 MB. Please choose a smaller photo.");
    onSelect(selected);
  };

  // Allow pasting a screenshot / copied image with Ctrl+V
  useEffect(() => {
    const onPaste = (e) => {
      const item = [...(e.clipboardData?.items || [])].find((i) => i.type.startsWith("image/"));
      if (item) selectFile(item.getAsFile());
    };
    window.addEventListener("paste", onPaste);
    return () => window.removeEventListener("paste", onPaste);
  });

  const onDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    selectFile(e.dataTransfer.files?.[0]);
  };

  const shownError = localError || error;

  return (
    <section className={compact ? "card upload-card compact" : "card upload-card"}>
      {!preview ? (
        <div
          className={dragging ? "dropzone dragging" : "dropzone"}
          role="button"
          tabIndex={0}
          onClick={() => inputRef.current?.click()}
          onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && inputRef.current?.click()}
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={onDrop}
        >
          <div className="dropzone-icon">🌿</div>
          <p className="dropzone-title">Drag &amp; drop a leaf image here</p>
          <p className="dropzone-sub">or click to browse · JPG, PNG, WEBP · max 10 MB</p>
          <button
            type="button"
            className="btn btn-ghost camera-btn"
            onClick={(e) => { e.stopPropagation(); cameraRef.current?.click(); }}
          >
            📷 Take a photo
          </button>
        </div>
      ) : (
        <div className="preview">
          <div className={loading ? "preview-frame scanning" : "preview-frame"}>
            <img src={preview} alt="Selected leaf" />
            {loading && <div className="scan-line" />}
          </div>
          <div className="preview-meta">
            <div className="file-info">
              <span className="file-name" title={file?.name}>{file?.name || "Pasted image"}</span>
              <span className="file-size">{file ? formatSize(file.size) : ""}</span>
            </div>
            {!loading && (
              <button className="link-btn" onClick={() => inputRef.current?.click()}>Change</button>
            )}
          </div>
        </div>
      )}

      <input ref={inputRef} type="file" accept=".jpg,.jpeg,.png,.webp" hidden
        onChange={(e) => { selectFile(e.target.files?.[0]); e.target.value = ""; }} />
      <input ref={cameraRef} type="file" accept="image/*" capture="environment" hidden
        onChange={(e) => { selectFile(e.target.files?.[0]); e.target.value = ""; }} />

      {shownError && <div className="alert alert-error" role="alert">⚠️ {shownError}</div>}

      {!compact && (
        <button className="btn btn-primary btn-block" disabled={!file || loading || disabled} onClick={onAnalyze}>
          {loading ? (<><span className="spinner" /> Analyzing leaf…</>) : "Analyze leaf"}
        </button>
      )}
      {compact && (
        <button className="btn btn-ghost btn-block" onClick={onReset}>Scan another leaf</button>
      )}

      {!compact && (
        <ul className="tips">
          <li>Use a clear, well-lit photo of a single leaf</li>
          <li>Fill most of the frame with the leaf</li>
          <li>Supported crops: apple, corn, grape, potato, tomato, pepper and more</li>
        </ul>
      )}
    </section>
  );
}
