import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// During development, /api requests are proxied to the Flask backend,
// so the browser never needs to know the backend URL.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/api": { target: "http://localhost:5000", changeOrigin: true },
    },
  },
});
