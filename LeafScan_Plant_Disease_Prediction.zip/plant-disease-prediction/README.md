# 🌿 LeafScan — Plant Disease Prediction using AI

A full-stack web application that identifies plant diseases from a single photo of a leaf.
A **MobileNetV2** CNN (transfer learning, fine-tuned on the **PlantVillage** dataset) classifies
**38 classes across 14 crops**, and a **React** interface shows the disease, confidence, top-3
predictions and practical cause / symptoms / treatment / prevention advice.

> Internship project — Artificial Intelligence & Machine Learning
> Techno Future India Pvt. Ltd., Hyderabad · KKR & KSR Institute of Technology and Sciences

---

## Features

- 📤 Drag-and-drop, click-to-browse, **paste (Ctrl+V)** or **take a photo** on mobile
- 🔬 Scanning animation while the model runs, result in under a second on a normal CPU
- 📊 Confidence bar (colour coded), **low-confidence warning** below 60 %, top-3 predictions
- 💊 Cause, symptoms, treatment and prevention for all 38 classes
- 🖨️ One-click **printable report** of a diagnosis
- 🕓 Prediction **history** with thumbnails, stats and clear-history (with confirmation)
- 📚 Searchable **disease library** with crop filters and healthy / disease toggle
- 🟢 Live server / model status badge with helpful messages when something is wrong
- 📱 Fully responsive (desktop, tablet, phone)

## Tech stack

| Layer | Technology |
|---|---|
| Frontend | React 18, Vite 5, plain CSS |
| Backend | Python 3.10–3.12, Flask 3, Flask-CORS |
| Model | TensorFlow / Keras, MobileNetV2 (ImageNet weights) |
| Database | SQLite 3 |
| Dataset | PlantVillage — *New Plant Diseases Dataset (Augmented)*, Kaggle |

## Project structure

```
plant-disease-prediction/
├── backend/
│   ├── app.py              # Flask REST API (also serves the built frontend)
│   ├── train.py            # model training (two-stage transfer learning)
│   ├── config.py           # paths and settings
│   ├── disease_info.py     # knowledge base for 38 classes
│   ├── test_api.py         # command-line API tester (TC01–TC12)
│   ├── requirements.txt
│   ├── model/              # plant_disease_model.h5, class_names.json, training_history.png
│   └── utils/
│       ├── predictor.py    # loads model, runs prediction
│       ├── preprocess.py   # image loading / resizing / label formatting
│       └── database.py     # SQLite prediction history
├── frontend/
│   ├── package.json, vite.config.js, index.html
│   └── src/
│       ├── App.jsx, api.js, index.css, main.jsx
│       └── components/     # Header, UploadSection, ResultCard, History, DiseaseLibrary, About
└── notebooks/
    └── train_on_colab.ipynb
```

---

## 1. Train the model (Google Colab — recommended)

Training needs a GPU. The free Colab T4 GPU takes about 30–45 minutes.

1. Open `notebooks/train_on_colab.ipynb` in [Google Colab](https://colab.research.google.com)
   (File → Upload notebook).
2. Runtime → Change runtime type → **T4 GPU**.
3. Run all cells. When asked, upload `kaggle.json`
   (Kaggle → Settings → API → *Create New Token*) and the `backend` folder as a zip.
4. Download the produced `model.zip` and extract it into `backend/model/`, so it contains
   `plant_disease_model.h5` and `class_names.json`.

**Or train locally** (needs a CUDA GPU for reasonable speed):

```bash
cd backend
python train.py --data "<dataset>/train" --val "<dataset>/valid"
```

At the end it prints the numbers for Table 8.1 of the report:

```
[RESULT] Training accuracy   : ...
[RESULT] Validation accuracy : ...
[RESULT] Validation loss     : ...
[RESULT] Model size          : ... MB
[RESULT] Avg prediction time : ... ms
```

and saves `model/training_history.png` (Fig 8.1) and `model/metrics.json`.

## 2. Run the backend

```bash
cd backend
python -m venv venv
# Windows: venv\Scripts\activate      macOS / Linux: source venv/bin/activate
pip install -r requirements.txt
python app.py
```

API runs at **http://localhost:5000**. Without a model file the server still starts and the
health endpoint explains what is missing.

## 3. Run the frontend

In a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Open **http://localhost:5173**, upload a leaf image and click **Analyze leaf**.

### Single-server mode

Run `npm run build` once inside `frontend/`. Flask then serves the built app too, so
`python app.py` alone gives you the whole application at http://localhost:5000.

## 4. Test the API

With the backend running:

```bash
cd backend
python test_api.py                            # validation / error cases
python test_api.py --image path/to/leaf.jpg   # plus a real prediction
```

---

## REST API

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/health` | Server status and whether the model is loaded |
| POST | `/api/predict` | Upload an image (form field `image`) → prediction JSON |
| GET | `/api/diseases` | All 38 classes with disease information |
| GET | `/api/history?limit=50` | Recent predictions |
| DELETE | `/api/history` | Clear the prediction history |
| GET | `/api/stats` | Total, healthy and diseased counts |
| GET | `/api/uploads/<file>` | Uploaded image (history thumbnails) |

Example `POST /api/predict` response:

```json
{
  "id": 12,
  "plant": "Tomato",
  "disease": "Late Blight",
  "is_healthy": false,
  "confidence": 0.9731,
  "uncertain": false,
  "top_predictions": [
    { "plant": "Tomato", "disease": "Late Blight", "confidence": 0.9731 },
    { "plant": "Tomato", "disease": "Early Blight", "confidence": 0.0184 },
    { "plant": "Potato", "disease": "Late Blight", "confidence": 0.0042 }
  ],
  "info": { "description": "...", "cause": "...", "symptoms": [], "treatment": [], "prevention": [] },
  "inference_ms": 74.2
}
```

Error codes: `400` missing / empty / unsupported file · `413` file over 10 MB ·
`422` unreadable image · `503` model not loaded.

## Configuration

All settings are in `backend/config.py`: image size, 60 % confidence threshold, 10 MB upload
limit, allowed extensions, paths. Environment variables: `PORT`, `MODEL_PATH`, `CORS_ORIGINS`,
`FLASK_DEBUG=1`. For a separately hosted frontend set `VITE_API_URL` (see `frontend/.env.example`).

## Troubleshooting

| Problem | Fix |
|---|---|
| Badge shows **Server offline** | Start the backend: `python app.py` in `backend/` |
| Badge shows **Model not loaded** | Put `plant_disease_model.h5` and `class_names.json` in `backend/model/` |
| `pip install tensorflow` fails | Use Python 3.10–3.12 (64-bit) |
| Low-confidence results on field photos | Expected — PlantVillage images have plain backgrounds. Crop close to one leaf. |

## Limitations

- Trained on lab images with plain backgrounds; accuracy is lower on cluttered field photos.
- Recognises only the 38 trained classes; other plants map to the nearest class (flagged as low confidence).
- Advice is general guidance and does not replace an agricultural expert.

## References

1. S. P. Mohanty, D. P. Hughes, M. Salathé, "Using Deep Learning for Image-Based Plant Disease Detection," *Frontiers in Plant Science*, 2016.
2. M. Sandler et al., "MobileNetV2: Inverted Residuals and Linear Bottlenecks," *CVPR*, 2018.
3. New Plant Diseases Dataset (Augmented) — https://www.kaggle.com/datasets/vipoooool/new-plant-diseases-dataset
